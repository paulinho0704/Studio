document.getElementById('navToggle')?.addEventListener('click', function(){
    document.getElementById('navMenu').classList.toggle('show');
});
function checkPassword(){
    const pass = document.getElementById('adminPass').value;
    if(pass === '07042009'){
        document.getElementById('adminContent').style.display='block';
        alert('Senha correta! Área administrativa liberada.');
    } else {
        alert('Senha incorreta!');
    }
}